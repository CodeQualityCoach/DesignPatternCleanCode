﻿namespace DiTryouts.Models
{
    public interface IMyLogger
    {
        void Log(string message);
    }
}