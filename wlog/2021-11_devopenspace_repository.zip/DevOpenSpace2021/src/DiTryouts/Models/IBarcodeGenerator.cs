﻿namespace DiTryouts.Models
{
    public interface IBarcodeGenerator
    {
    }
}