﻿namespace DiTryouts.Models
{
    public interface IPdfGenerator
    {
    }
}