﻿# Readme

## Actions

* create
* addbarcode

## Action `create`

* parameter: infile outfile
